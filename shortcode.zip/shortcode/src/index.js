const express = require('express');
const exphbs = require('express-handlebars');
const Handlebars = require('handlebars');
const { Sequelize, DataTypes } = require('sequelize');
const mysql = require('mysql2');
const sequelize = new Sequelize('node_makaan', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
});

const app = express();

// Tạo đối tượng handlebars và đăng ký helper
const handlebarsInstance = exphbs.create({
    extname: '.hbs',
    helpers: {
        sum: (a, b) => a + b,
        eq: function (a, b) {
            return a === b;
        },
        ifEquals: function (arg1, arg2, options) {
            return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
        },

    }
});

// Kiểm tra kết nối
sequelize.authenticate()
    .then(() => {
        console.log('Connection to MySQL has been established successfully.');
    })
    .catch(err => {
        console.error('Unable to connect to MySQL:', err);
    });

// Định nghĩa một mô hình (model) ví dụ
const Agent = sequelize.define('Agent', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    designation: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    tableName: 'agents'
});

const Page = sequelize.define('Page', {
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    detail: {
        type: DataTypes.TEXT,
        allowNull: false
    }
}, {
    tableName: 'pages'
});

// Đồng bộ mô hình với cơ sở dữ liệu
sequelize.sync()
    .then(() => {
        console.log('Page model was synchronized successfully.');
    });

// Cấu hình express để sử dụng handlebars
app.engine('hbs', handlebarsInstance.engine);
app.set('view engine', 'hbs');
app.set('views', './views');

// Hàm xử lý shortcode
function parseAttributes(attrString) {
    const attrs = {};
    attrString.split(' ').forEach(attr => {
        const parts = attr.split('=');
        const key = parts[0];
        const value = parts[1] ? parts[1].replace(/['"]/g, '') : ''; // Remove quotes around attribute values
        attrs[key] = value;
    });
    return attrs;
}

async function processShortcodes(content) {
    if (!content) {
        return content;
    }

    const shortcodePattern = /\[([a-zA-Z0-9_]+)(.*?)\]/g;

    // Lưu trữ các kết quả thay thế
    const replacements = [];
    const agentsPromise = Agent.findAll({ raw: true });
    content.replace(shortcodePattern, (match, shortcode, attrs) => {
        const options = parseAttributes(attrs.trim());

        switch (shortcode) {
            case 'greeting':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const agents = await agentsPromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`
                            <ul>
                            {{#each agents}}
                                <li>{{this.name}}</li>
                            {{/each}}
                            </ul>
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ agents });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            default:
                replacements.push(Promise.resolve({ match, replacement: match }));
        }
    });

    // Chờ tất cả các promise hoàn tất
    const results = await Promise.all(replacements);

    // Thay thế nội dung
    results.forEach(({ match, replacement }) => {
        content = content.replace(match, replacement);
    });

    return content;
}

app.get('/', async (req, res) => {
    try {
        // Giả sử page.detail chứa nội dung từ cơ sở dữ liệu
        const page = {
            title: 'Shortcode Example',
            detail: 'This is a [greeting ]'
        };

        // Xử lý shortcode trong nội dung
        page.detail = await processShortcodes(page.detail);

        res.render('home', { page });
    } catch (error) {
        console.error('Error processing shortcodes:', error);
        res.status(500).send('Internal Server Error');
    }
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
