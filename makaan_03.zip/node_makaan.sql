-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2024 at 04:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `node_makaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminnavs`
--

CREATE TABLE `adminnavs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminnavs`
--

INSERT INTO `adminnavs` (`id`, `name`, `link`, `parent_id`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Menu', '/wp-admin/menu', 0, 1, '2024-07-30 00:15:39', '2024-07-30 00:16:39'),
(2, 'Slide', '/wp-admin/slide', 0, 1, '2024-07-30 01:04:14', '2024-07-30 01:04:14'),
(3, 'Property Type', '/wp-admin/property-type', 0, 1, '2024-07-30 01:06:59', '2024-07-30 01:07:02'),
(4, 'Property', '/wp-admin/property', 0, 1, '2024-07-30 01:20:27', '2024-07-30 01:20:27'),
(5, 'Agent', '/wp-admin/agent', 0, 1, '2024-07-30 01:27:01', '2024-07-30 01:27:01'),
(6, 'Clients Say', '/wp-admin/clientsay', 0, 1, '2024-07-30 01:29:17', '2024-07-30 01:29:17'),
(7, 'Pages', '/wp-admin/pages', 0, 1, '2024-07-30 01:34:07', '2024-07-30 01:34:07');

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`id`, `name`, `imagePath`, `designation`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Full Name', '1722302883259-team-1.jpg', 'Designation', 1, '2024-07-30 01:28:03', '2024-08-01 14:52:44'),
(2, 'Full Name 2', '1722302892779-team-2.jpg', 'Designation 2', 1, '2024-07-30 01:28:12', '2024-08-01 14:52:46'),
(3, 'Full Name 3', '1722302904053-team-3.jpg', 'Designation 3', 1, '2024-07-30 01:28:24', '2024-08-01 14:52:41'),
(4, 'Full Name 4', '1722302915014-team-4.jpg', 'Designation 4', 1, '2024-07-30 01:28:35', '2024-08-01 14:52:41');

-- --------------------------------------------------------

--
-- Table structure for table `clientsays`
--

CREATE TABLE `clientsays` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clientsays`
--

INSERT INTO `clientsays` (`id`, `name`, `imagePath`, `description`, `designation`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Client Name', '1722303001747-testimonial-1.jpg', 'Profession', ' Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd erat eos', 1, '2024-07-30 01:30:01', '2024-08-01 14:52:36'),
(2, 'Client Name 2', '1722303025465-testimonial-2.jpg', 'Profession 2', ' Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd erat eos', 1, '2024-07-30 01:30:25', '2024-08-01 14:52:35'),
(3, 'Client Name 3', '1722303047075-testimonial-3.jpg', 'Profession 3', ' Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd erat eos', 1, '2024-07-30 01:30:47', '2024-08-01 14:52:35');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `link` varchar(200) NOT NULL,
  `position` varchar(50) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `link`, `position`, `parent_id`, `sort`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Home', '/', 'header', 0, 1, 0, '2024-07-30 00:17:55', '2024-08-01 14:49:21'),
(2, 'About', '/about', 'header', 0, 2, 1, '2024-07-30 00:48:53', '2024-08-01 14:53:21'),
(3, 'Property', '/property', 'header', 0, 3, 1, '2024-07-30 00:49:59', '2024-08-01 14:53:21'),
(4, 'Property List', '/property', 'header', 3, 4, 1, '2024-07-30 00:50:31', '2024-08-01 14:53:22'),
(5, 'Property Type', '/property-type', 'header', 3, 5, 1, '2024-07-30 00:51:02', '2024-08-01 14:53:22'),
(6, 'Property Agents', '/property-agents', 'header', 3, 6, 1, '2024-07-30 01:02:07', '2024-08-01 14:53:25'),
(7, 'Testimonial', '/testimonial', 'header', 0, 7, 1, '2024-07-30 01:02:38', '2024-08-01 14:53:24'),
(8, 'Contact', '/contact', 'header', 0, 8, 1, '2024-07-30 01:02:57', '2024-08-01 14:53:26'),
(9, 'About Us', '/about', 'footer01', 0, 9, 1, '2024-07-30 01:31:16', '2024-08-01 14:53:27'),
(10, 'Contact Us', '/contact', 'footer01', 0, 10, 1, '2024-07-30 01:31:40', '2024-08-01 14:53:27'),
(11, 'Home', '/', 'footer02', 0, 12, 1, '2024-07-30 01:32:08', '2024-07-30 01:32:08');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `imagePath`, `detail`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'About Us', 'about', '1722303962953-header.jpg', '<div>[search]</div>\r\n<div>[perfect id=\"1\"]</div>\r\n<div>[certified]</div>\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting ]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->', 1, '2024-07-30 01:46:02', '2024-08-01 14:46:03'),
(2, 'Property List', 'property', '1722305928242-header.jpg', '<div>[search]</div>\r\n<!-- Property List Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"row g-0 gx-5 align-items-end\">\r\n<div class=\"col-lg-6\">\r\n<div class=\"text-start mx-auto mb-5 wow slideInLeft\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Listing</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit diam justo sed rebum.</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"tab-content\">\r\n<div id=\"tab-1\" class=\"tab-pane fade show p-0 active\">\r\n<div class=\"row g-4\">[property]</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- Property List End -->\r\n<p>&nbsp;</p>\r\n<div>[certified]</div>', 1, '2024-07-30 02:18:48', '2024-07-31 14:18:49'),
(3, 'Property Type', 'property-type', '1722306196997-header.jpg', '<div>[search]</div>\r\n<!-- Category Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Types</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[propertyType]</div>\r\n</div>\r\n</div>\r\n<!-- Category End -->', 1, '2024-07-30 02:23:17', '2024-07-31 13:58:50'),
(4, 'Property Agents', 'property-agents', '1722306422925-header.jpg', '<div>[search]</div>\r\n<!-- Team Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->\r\n<p>&nbsp;</p>\r\n<div>[certified]</div>', 1, '2024-07-30 02:27:02', '2024-07-31 14:19:40'),
(5, 'Testimonial', 'testimonial', '1722306484611-header.jpg', '<div>[search]</div>\r\n<!-- Testimonial Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Our Clients Say!</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"owl-carousel testimonial-carousel wow fadeInUp\" data-wow-delay=\"0.1s\">[clientsay]</div>\r\n</div>\r\n</div>\r\n<!-- Testimonial End -->', 1, '2024-07-30 02:28:04', '2024-07-31 14:06:36'),
(6, 'Contact Us', 'contact', '1722306767794-header.jpg', '', 1, '2024-07-30 02:32:47', '2024-07-30 02:32:47'),
(7, 'Home', 'home', '1722431601414-header.jpg', '<div>[search]</div>\r\n<!-- Category Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Types</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[propertyType titles=\"Property Types\"]</div>\r\n</div>\r\n</div>\r\n<!-- Category End -->\r\n<div>[perfect id=\"1\"]</div>\r\n<!-- Property List Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"row g-0 gx-5 align-items-end\">\r\n<div class=\"col-lg-6\">\r\n<div class=\"text-start mx-auto mb-5 wow slideInLeft\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Listing</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit diam justo sed rebum.</p>\r\n</div>\r\n</div>\r\n<div class=\"col-lg-6 text-start text-lg-end wow slideInRight\" data-wow-delay=\"0.1s\">\r\n<ul class=\"nav nav-pills d-inline-flex justify-content-end mb-5\">\r\n<li class=\"nav-item me-2\"><a class=\"btn btn-outline-primary active\" href=\"#tab-1\" data-bs-toggle=\"pill\">Featured</a></li>\r\n<li class=\"nav-item me-2\"><a class=\"btn btn-outline-primary\" href=\"#tab-2\" data-bs-toggle=\"pill\">For Sell</a></li>\r\n<li class=\"nav-item me-0\"><a class=\"btn btn-outline-primary\" href=\"#tab-3\" data-bs-toggle=\"pill\">For Rent</a></li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class=\"tab-content\">\r\n<div id=\"tab-1\" class=\"tab-pane fade show p-0 active\">\r\n<div class=\"row g-4\">[property]\r\n<div class=\"col-12 text-center wow fadeInUp\" data-wow-delay=\"0.1s\"><a class=\"btn btn-primary py-3 px-5\">Browse More Property</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- Property List End -->\r\n<p>&nbsp;</p>\r\n<p>[certified]</p>\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting ]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->\r\n<p>&nbsp;</p>\r\n<!-- Testimonial Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Our Clients Say!</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"owl-carousel testimonial-carousel wow fadeInUp\" data-wow-delay=\"0.1s\">[clientsay]</div>\r\n</div>\r\n</div>\r\n<!-- Testimonial End -->', 1, '2024-07-31 13:13:21', '2024-08-01 14:41:09');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `acreage` int(11) NOT NULL,
  `bed` int(11) NOT NULL,
  `bath` int(11) NOT NULL,
  `property_type` int(11) NOT NULL,
  `detail` text NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `name`, `imagePath`, `price`, `address`, `acreage`, `bed`, `bath`, `property_type`, `detail`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Golden Urban House For Sell', '1722302463511-property-1.jpg', 12345, '123 Street, New York, USA', 1000, 3, 2, 1, '<p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>\r\n<p><em class=\"fa fa-check text-primary me-3\"> </em>Tempor erat elitr rebum at clita</p>\r\n<p><em class=\"fa fa-check text-primary me-3\"> </em>Aliqu diam amet diam et eos</p>\r\n<p><em class=\"fa fa-check text-primary me-3\"> </em>Clita duo justo magna dolore erat amet</p>', 1, '2024-07-30 01:21:03', '2024-08-01 14:52:56'),
(2, 'Golden Urban House For Sell 2', '1722302511415-property-2.jpg', 23456, '200 Street, New York, USA', 2000, 4, 3, 1, '', 1, '2024-07-30 01:21:51', '2024-08-01 14:52:54'),
(3, 'Golden Urban House For Sell 3', '1722302533982-property-3.jpg', 34567, '300 Street, New York, USA', 3000, 5, 4, 4, '', 1, '2024-07-30 01:22:13', '2024-08-01 14:52:54'),
(4, 'Golden Urban House For Sell 4', '1722302583656-property-4.jpg', 45678, '400 Street, New York, USA', 4000, 4, 3, 5, '', 1, '2024-07-30 01:23:03', '2024-08-01 14:52:53'),
(5, 'Golden Urban House For Sell 5', '1722302612026-property-5.jpg', 56789, '500 Street, New York, USA', 5000, 5, 4, 3, '', 1, '2024-07-30 01:23:32', '2024-08-01 14:52:51'),
(6, 'Golden Urban House For Sell 6', '1722302640073-property-6.jpg', 67891, '600 Street, New York, USA', 6000, 6, 4, 7, '', 1, '2024-07-30 01:24:00', '2024-08-01 14:52:53');

-- --------------------------------------------------------

--
-- Table structure for table `property_types`
--

CREATE TABLE `property_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_types`
--

INSERT INTO `property_types` (`id`, `name`, `imagePath`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'Apartment', '1722302285780-icon-apartment.png', 1, '2024-07-30 01:18:05', '2024-08-01 14:53:02'),
(2, 'Villa', '1722302307514-icon-villa.png', 1, '2024-07-30 01:18:27', '2024-08-01 14:53:03'),
(3, 'Home', '1722302320481-icon-house.png', 1, '2024-07-30 01:18:40', '2024-08-01 14:53:04'),
(4, 'Office', '1722302331920-icon-housing.png', 1, '2024-07-30 01:18:51', '2024-08-01 14:53:04'),
(5, 'Building', '1722302344219-icon-building.png', 1, '2024-07-30 01:19:04', '2024-08-01 14:53:05'),
(6, 'Townhouse', '1722302367395-icon-neighborhood.png', 1, '2024-07-30 01:19:27', '2024-08-01 14:53:06'),
(7, 'Shop', '1722302380724-icon-condominium.png', 1, '2024-07-30 01:19:40', '2024-08-01 14:53:06'),
(8, 'Garage', '1722302395741-icon-luxury.png', 1, '2024-07-30 01:19:55', '2024-08-01 14:53:07');

-- --------------------------------------------------------

--
-- Table structure for table `slides`
--

CREATE TABLE `slides` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slides`
--

INSERT INTO `slides` (`id`, `name`, `imagePath`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'slide 01', '1722301507727-carousel-1.jpg', 1, '2024-07-30 01:05:07', '2024-08-01 14:53:10'),
(2, 'Slide 02', '1722301574567-carousel-2.jpg', 1, '2024-07-30 01:06:14', '2024-08-01 14:53:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminnavs`
--
ALTER TABLE `adminnavs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clientsays`
--
ALTER TABLE `clientsays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_types`
--
ALTER TABLE `property_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slides`
--
ALTER TABLE `slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminnavs`
--
ALTER TABLE `adminnavs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clientsays`
--
ALTER TABLE `clientsays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `property_types`
--
ALTER TABLE `property_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `slides`
--
ALTER TABLE `slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
