-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2024 at 04:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `node_makaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `imagePath` varchar(255) NOT NULL,
  `detail` text NOT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `imagePath`, `detail`, `status`, `createdAt`, `updatedAt`) VALUES
(1, 'About Us', 'about', '1722303962953-header.jpg', '<div>[search]</div>\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting ]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->', 1, '2024-07-30 01:46:02', '2024-07-31 13:09:48'),
(2, 'Property List', 'property', '1722305928242-header.jpg', '<div>[search]</div>\r\n<!-- Property List Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"row g-0 gx-5 align-items-end\">\r\n<div class=\"col-lg-6\">\r\n<div class=\"text-start mx-auto mb-5 wow slideInLeft\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Listing</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit diam justo sed rebum.</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"tab-content\">\r\n<div id=\"tab-1\" class=\"tab-pane fade show p-0 active\">\r\n<div class=\"row g-4\">[property]</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- Property List End -->\r\n<p>&nbsp;</p>\r\n<div>[certified]</div>', 1, '2024-07-30 02:18:48', '2024-07-31 14:18:49'),
(3, 'Property Type', 'property-type', '1722306196997-header.jpg', '<div>[search]</div>\r\n<!-- Category Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Types</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[propertyType]</div>\r\n</div>\r\n</div>\r\n<!-- Category End -->', 1, '2024-07-30 02:23:17', '2024-07-31 13:58:50'),
(4, 'Property Agents', 'property-agents', '1722306422925-header.jpg', '<div>[search]</div>\r\n<!-- Team Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->\r\n<p>&nbsp;</p>\r\n<div>[certified]</div>', 1, '2024-07-30 02:27:02', '2024-07-31 14:19:40'),
(5, 'Testimonial', 'testimonial', '1722306484611-header.jpg', '<div>[search]</div>\r\n<!-- Testimonial Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Our Clients Say!</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"owl-carousel testimonial-carousel wow fadeInUp\" data-wow-delay=\"0.1s\">[clientsay]</div>\r\n</div>\r\n</div>\r\n<!-- Testimonial End -->', 1, '2024-07-30 02:28:04', '2024-07-31 14:06:36'),
(6, 'Contact Us', 'contact', '1722306767794-header.jpg', '', 1, '2024-07-30 02:32:47', '2024-07-30 02:32:47'),
(7, 'Home', 'home', '1722431601414-header.jpg', '<div>[search]</div>\r\n<!-- Category Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Types</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[propertyType]</div>\r\n</div>\r\n</div>\r\n<!-- Category End -->\r\n<p>&nbsp;</p>\r\n<!-- About Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"row g-5 align-items-center\">\r\n<div class=\"col-lg-6 wow fadeIn\" data-wow-delay=\"0.1s\">\r\n<div class=\"about-img position-relative overflow-hidden p-5 pe-0\"><img class=\"img-fluid w-100\" src=\"img/about.jpg\"></div>\r\n</div>\r\n<div class=\"col-lg-6 wow fadeIn\" data-wow-delay=\"0.5s\">\r\n<h1 class=\"mb-4\">#1 Place To Find The Perfect Property</h1>\r\n<p class=\"mb-4\">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>\r\n<p>Tempor erat elitr rebum at clita</p>\r\n<p>Aliqu diam amet diam et eos</p>\r\n<p>Clita duo justo magna dolore erat amet</p>\r\n<a class=\"btn btn-primary py-3 px-5 mt-3\">Read More</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- About End -->\r\n<p>&nbsp;</p>\r\n<!-- Property List Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"row g-0 gx-5 align-items-end\">\r\n<div class=\"col-lg-6\">\r\n<div class=\"text-start mx-auto mb-5 wow slideInLeft\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Listing</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit diam justo sed rebum.</p>\r\n</div>\r\n</div>\r\n<div class=\"col-lg-6 text-start text-lg-end wow slideInRight\" data-wow-delay=\"0.1s\">\r\n<ul class=\"nav nav-pills d-inline-flex justify-content-end mb-5\">\r\n<li class=\"nav-item me-2\"><a class=\"btn btn-outline-primary active\" href=\"#tab-1\" data-bs-toggle=\"pill\">Featured</a></li>\r\n<li class=\"nav-item me-2\"><a class=\"btn btn-outline-primary\" href=\"#tab-2\" data-bs-toggle=\"pill\">For Sell</a></li>\r\n<li class=\"nav-item me-0\"><a class=\"btn btn-outline-primary\" href=\"#tab-3\" data-bs-toggle=\"pill\">For Rent</a></li>\r\n</ul>\r\n</div>\r\n</div>\r\n<div class=\"tab-content\">\r\n<div id=\"tab-1\" class=\"tab-pane fade show p-0 active\">\r\n<div class=\"row g-4\">[property]\r\n<div class=\"col-12 text-center wow fadeInUp\" data-wow-delay=\"0.1s\"><a class=\"btn btn-primary py-3 px-5\">Browse More Property</a></div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<!-- Property List End -->\r\n<p>&nbsp;</p>\r\n<p>[certified]</p>\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Property Agents</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"row g-4\">[greeting ]</div>\r\n</div>\r\n</div>\r\n<!-- Team End -->\r\n<p>&nbsp;</p>\r\n<!-- Testimonial Start -->\r\n<div class=\"container-xxl py-5\">\r\n<div class=\"container\">\r\n<div class=\"text-center mx-auto mb-5 wow fadeInUp\" style=\"max-width: 600px;\" data-wow-delay=\"0.1s\">\r\n<h1 class=\"mb-3\">Our Clients Say!</h1>\r\n<p>Eirmod sed ipsum dolor sit rebum labore magna erat. Tempor ut dolore lorem kasd vero ipsum sit eirmod sit. Ipsum diam justo sed rebum vero dolor duo.</p>\r\n</div>\r\n<div class=\"owl-carousel testimonial-carousel wow fadeInUp\" data-wow-delay=\"0.1s\">[clientsay]</div>\r\n</div>\r\n</div>\r\n<!-- Testimonial End -->', 1, '2024-07-31 13:13:21', '2024-07-31 14:17:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
