const express = require('express');
const session = require('express-session');
const app = express();
const port = 2000;
const numeral = require('numeral');

const handlebars = require('express-handlebars')
const Handlebars = require('handlebars');
const path = require('path')
const loadMenu = require('./middleware/menuMiddleware');

const bodyParser = require('body-parser');

app.use(loadMenu);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname, 'public')));


app.engine('hbs', handlebars.engine({
    extname: '.hbs',
    helpers: {
        sum: (a, b) => a + b,
        eq: function (a, b) {
            return a === b;
        },
        ifEquals: function (arg1, arg2, options) {
            return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
        },
        formatNumber: function (value) {
            return numeral(value).format('0,0');
        },
        shortcode: function (name, options) {
            if (name === 'greeting') {
                const name = options.hash.name || 'Guest';
                return new Handlebars.SafeString(`<p>Hello, ${name}!</p>`);
            }
            return new Handlebars.SafeString('');
        }
    }
}));
app.set('view engine', 'hbs')
app.set('views', path.join(__dirname, 'resources', 'views'))



//đặt sự kiện sestion
app.use(session({
    secret: 'your-secret-key', // Thay đổi thành khóa bí mật của bạn
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));


//router
const route = require('./routes');
route(app);


app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
})
