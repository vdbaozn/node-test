// src/middleware/menuMiddleware.js
const Menu = require('../app/models/Adminnav'); // Đường dẫn đến model Menu của bạn
async function menuAdmin(req, res, next) {
    try {
        const admenus = await Menu.findAll({ where: { parent_id: 0, status: '1' }, raw: true });

        for (const menu of admenus) {
            menu.children = await Menu.findAll({
                where: { parent_id: menu.id, status: '1' },
                raw: true,
            });
        }

        res.locals.admenus = admenus;
        next();
    } catch (error) {
        next(error);
    }
}

module.exports = menuAdmin;
