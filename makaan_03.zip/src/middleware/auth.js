function authenticateSession(req, res, next) {
    if (req.originalUrl === '/wp-admin/login') {
        return next(); // Nếu là trang đăng nhập, cho phép truy cập
    }

    if (req.session.user) {
        return next(); // Nếu session tồn tại, cho phép truy cập
    } else {
        res.redirect('/wp-admin/login'); // Nếu không có session, chuyển hướng đến trang đăng nhập
    }
}

module.exports = authenticateSession;


