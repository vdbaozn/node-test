// src/middleware/menuMiddleware.js
const Menu = require('../app/models/Menu'); // Đường dẫn đến model Menu của bạn
const Property = require('../app/models/Property');
const Page = require('../app/models/Page');
async function loadMenu(req, res, next) {
    try {
        const menus = await Menu.findAll({ where: { parent_id: 0, position: 'header', status: '1' }, order: [['sort', 'ASC']], raw: true });
        const menufoot01 = await Menu.findAll({ where: { parent_id: 0, position: 'footer01', status: '1' }, raw: true });
        const menufoot02 = await Menu.findAll({ where: { parent_id: 0, position: 'footer02', status: '1' }, raw: true });
        const gallery_foot = await Property.findAll({ where: { status: 1 }, limit: 6, raw: true });

        //findByPk(req.params.id)
        //const page = await Page.findOne({ raw: true, where: { status: 1, slug: 'about' } })

        for (const menu of menus) {
            menu.children = await Menu.findAll({
                where: { parent_id: menu.id, status: '1' },
                raw: true,
            });
        }

        res.locals.menus = menus;
        res.locals.menufoot01 = menufoot01;
        res.locals.menufoot02 = menufoot02;
        res.locals.gallery_foot = gallery_foot;
        // res.locals.page = page;
        next();
    } catch (error) {
        next(error);
    }
}

module.exports = loadMenu;
