const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const User = sequelize.define('user', {
    username: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    }

}, {
    timestamps: true,
});
async function initializeDatabase() {
    try {
        await sequelize.authenticate();
        await User.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}
initializeDatabase();
module.exports = User;
