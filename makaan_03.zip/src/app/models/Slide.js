const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const Slide = sequelize.define('slide', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
 
    imagePath: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

}, {
    timestamps: true,
   
});

// Kiểm tra và tạo bảng nếu chưa tồn tại
async function initializeDatabase() {
    try {
        await sequelize.authenticate();

        await Slide.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}

initializeDatabase();

module.exports = Slide;
