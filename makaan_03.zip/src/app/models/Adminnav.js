const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const Adminnav = sequelize.define('adminnav', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    link: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

}, {
    timestamps: true,

});

async function initializeDatabase() {
    try {
        await sequelize.authenticate();
        await Adminnav.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}

initializeDatabase();

module.exports = Adminnav;
