const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const ClientSay = sequelize.define('clientsay', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    imagePath: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    description: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    designation: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

}, {
    timestamps: true,
});

async function initializeDatabase() {
    try {
        await sequelize.authenticate();
        await ClientSay.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}

initializeDatabase();

module.exports = ClientSay;
