const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const PropertyType = sequelize.define('property_type', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    imagePath: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

}, {
    timestamps: true,
});

async function initializeDatabase() {
    try {
        await sequelize.authenticate();
        await PropertyType.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}

initializeDatabase();

module.exports = PropertyType;
