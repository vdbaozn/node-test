const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const Property = sequelize.define('property', {
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    imagePath: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    price: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    address: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    acreage: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    bed: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    bath: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    property_type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    detail: {
        type: DataTypes.TEXT,
        allowNull: false,
    },

    status: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

}, {
    timestamps: true,

});

async function initializeDatabase() {
    try {
        await sequelize.authenticate();
        await Property.sync(); // Tạo bảng nếu chưa tồn tại
    } catch (error) {
    }
}

initializeDatabase();

module.exports = Property;
