const Menu = require("../models/Menu");
const Slide = require("../models/Slide");
const PropertyType = require("../models/PropertyType");
const Property = require("../models/Property");
const Agent = require("../models/Agent");
const ClientSay = require("../models/ClientSay");
const Page = require("../models/Page");
const express = require('express');
const Handlebars = require('handlebars');

function parseAttributes(attributeString) {
    const attributes = {};
    const regex = /(\w+)="([^"]*)"/g;
    let match;

    while ((match = regex.exec(attributeString)) !== null) {
        attributes[match[1]] = match[2];
    }

    return attributes;
}

async function processShortcodes(content) {
    if (!content) {
        return content;
    }

    const shortcodePattern = /\[([a-zA-Z0-9_]+)(.*?)\]/g;

    // Lưu trữ các kết quả thay thế
    const replacements = [];
    const agentsPromise = Agent.findAll({ raw: true, where: {status: 1} });
    const proTypePromise = PropertyType.findAll({ raw: true, where: {status: 1} });
    const propertiesPromise = Property.findAll({ raw: true, where: {status: 1} });
    const clientsayPromise = ClientSay.findAll({ raw: true, where: {status: 1} });
    
    
    content.replace(shortcodePattern, (match, shortcode, attrs) => {
        const options = parseAttributes(attrs.trim());

        switch (shortcode) {
            case 'greeting':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const agents = await agentsPromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`               
                            {{#each agents}}
                            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="team-item rounded overflow-hidden">
                                    <div class="position-relative">
                                        <img class="img-fluid" src="/uploads/{{this.imagePath}}" alt="{{this.name}}">
                                        <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                            <a class="btn btn-square mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                            <a class="btn btn-square mx-1" href=""><i class="fab fa-twitter"></i></a>
                                            <a class="btn btn-square mx-1" href=""><i class="fab fa-instagram"></i></a>
                                        </div>
                                    </div>
                                    <div class="text-center p-4 mt-3">
                                        <h5 class="fw-bold mb-0">{{this.name}}</h5>
                                        <small>{{this.designation}}</small>
                                    </div>
                                </div>
                            </div>
                            {{/each}}
                            <!-- Team End -->                           
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ agents });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'search':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const agents = await agentsPromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`               
                            <!-- Search Start -->
                            <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 35px;">
                                <div class="container">
                                    <div class="row g-2">
                                        <div class="col-md-10">
                                            <div class="row g-2">
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control border-0 py-3" placeholder="Search Keyword">
                                                </div>
                                                <div class="col-md-4">
                                                    <select class="form-select border-0 py-3">
                                                        <option selected>Property Type</option>
                                                        <option value="1">Property Type 1</option>
                                                        <option value="2">Property Type 2</option>
                                                        <option value="3">Property Type 3</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-4">
                                                    <select class="form-select border-0 py-3">
                                                        <option selected>Location</option>
                                                        <option value="1">Location 1</option>
                                                        <option value="2">Location 2</option>
                                                        <option value="3">Location 3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <button class="btn btn-dark border-0 w-100 py-3">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Search End -->                         
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ agents });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'certified':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const agents = await agentsPromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`               
                            <!-- Call to Action Start -->
                            <div class="container-xxl py-5">
                                <div class="container">
                                    <div class="bg-light rounded p-3">
                                        <div class="bg-white rounded p-4" style="border: 1px dashed rgba(0, 185, 142, .3)">
                                            <div class="row g-5 align-items-center">
                                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                                    <img class="img-fluid rounded w-100" src="img/call-to-action.jpg" alt="">
                                                </div>
                                                <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                                    <div class="mb-4">
                                                        <h1 class="mb-3">Contact With Our Certified Agent</h1>
                                                        <p>Eirmod sed ipsum dolor sit rebum magna erat. Tempor lorem kasd vero ipsum sit sit diam justo sed vero dolor duo.</p>
                                                    </div>
                                                    <a href="" class="btn btn-primary py-3 px-4 me-2"><i class="fa fa-phone-alt me-2"></i>Make A Call</a>
                                                    <a href="" class="btn btn-dark py-3 px-4"><i class="fa fa-calendar-alt me-2"></i>Get Appoinment</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Call to Action End -->                        
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ agents });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'perfect':
                replacements.push(
                    (async () => {
                        const id = options.id ;
                        const agents = await agentsPromise;
                        const pro = await Property.findOne({ where: { id: id}, raw: true });

                        // Tạo template Handlebars cho danh sách 
                        const agentTemplate = Handlebars.compile(`               
                             <!-- About Start -->
                            <div class="container-xxl py-5">
                                <div class="container">
                                    <div class="row g-5 align-items-center">
                                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                            <div class="about-img position-relative overflow-hidden p-5 pe-0">
                                                <img class="img-fluid w-100" src="/uploads/{{pro.imagePath}}">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                            <h1 class="mb-4">{{pro.name}}</h1>
                                            {{{pro.detail}}}
                                            <a class="btn btn-primary py-3 px-5 mt-3" href="property/{{pro.id}}/view">Read More </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- About End -->                      
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({id, pro });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'propertyType':
                replacements.push(
                    (async () => {
                        const titles = options.titles ;
                        const desc = options.desc ;
                        const proType = await proTypePromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`
                            {{#each proType}}
                            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                                <a class="cat-item d-block bg-light text-center rounded p-3" href="property-type/{{this.id}}/view">
                                    <div class="rounded p-4">
                                        <div class="icon mb-3">
                                            <img class="img-fluid" src="/uploads/{{this.imagePath}}" alt="Icon">
                                        </div>
                                        <h6>{{this.name}}</h6>
                                        <span>123 Properties </span>
                                    </div>
                                </a>
                            </div>
                            {{/each}}
                         
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ titles,desc, proType });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'property':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const properties = await propertiesPromise;

                        for (const propertie of properties) {
                            propertie.children = await PropertyType.findOne({ where: { id: propertie.property_type }, raw: true });
                        }

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`               
                            {{#each properties}}
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="property-item rounded overflow-hidden">
                                <div class="position-relative overflow-hidden"><a href="../../../property/{{this.id}}/view"><img class="img-fluid" src="../../../uploads/{{this.imagePath}}" alt=""></a>
                                <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">For Sell</div>
                                <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3">{{#if this.children}} {{this.children.name}} {{/if}}</div>
                                </div>
                                <div class="p-4 pb-0">
                                <h5 class="text-primary mb-3">$ {{this.price}}</h5>
                                <a class="d-block h5 mb-2" href="../../../property/{{this.id}}/view">{{this.name}}</a>
                                <p>{{this.address}}</p>
                                </div>
                                <div class="d-flex border-top"><small class="flex-fill text-center border-end py-2">{{this.acreage}} Sqft</small> <small class="flex-fill text-center border-end py-2">{{this.bed}} Bed</small> <small class="flex-fill text-center py-2">{{this.bath}} Bath</small></div>
                                </div>
                                </div>
                            {{/each}}
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ properties });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            case 'clientsay':
                replacements.push(
                    (async () => {
                        const name = options.name ;
                        const clientSay = await clientsayPromise;

                        // Tạo template Handlebars cho danh sách agents
                        const agentTemplate = Handlebars.compile(`               
                            {{#each clientSay}}
                            <div class="testimonial-item bg-light rounded p-3">
                            <div class="bg-white border rounded p-4">
                            <p>{{this.designation}}</p>
                            <div class="d-flex align-items-center"><img class="img-fluid flex-shrink-0 rounded" style="width: 45px; height: 45px;" src="../../../uploads/{{this.imagePath}}">
                            <div class="ps-3">
                            <h6 class="fw-bold mb-1">{{this.name}}</h6>
                            <small>{{this.description}}</small></div>
                            </div>
                            </div>
                            </div>
                            {{/each}}
                        `);

                        // Render danh sách agents
                        const agentHtml = agentTemplate({ clientSay });

                        const replacement = new Handlebars.SafeString(`
                            ${agentHtml}
                        `);
                        return { match, replacement: replacement.toString() };
                    })()
                );
                break;
            default:
                replacements.push(Promise.resolve({ match, replacement: match }));
        }
    });

    // Chờ tất cả các promise hoàn tất
    const results = await Promise.all(replacements);

    // Thay thế nội dung
    results.forEach(({ match, replacement }) => {
        content = content.replace(match, replacement);
    });

    return content;
}


class SiteController {
    async index(req, res, next) { //async   
        try {
            const slide = await Slide.findAll({ raw: true, where: { status: '1' } });           

            const ispage = await Page.findOne({ raw: true, where: { status: 1, slug: "home" } })
            if(ispage){
                ispage.detail = await processShortcodes(ispage.detail);
            }

            res.render('home', {
                slide: slide,                
                ispage: ispage,
            });

        } catch (error) {
            next(error);
        }
    }  

    async propertyview(req, res) {
        // res.send(req.params.id);
        const page = await Page.findOne({ raw: true, where: { status: 1, slug: 'property' } })
        const post = await Property.findOne({ raw: true, where: { status: 1, id: req.params.id } })

        res.render('property/detail', {
            page: page,
            post: post
        });
    }

    async propertytypeview(req, res) {
        // res.send(req.params.id);
        const page = await Page.findOne({ raw: true, where: { status: 1, slug: 'property-type' } })
        const cate = await PropertyType.findOne({ raw: true, where: { status: 1, id: req.params.id } })
        const property = await Property.findAll({ raw: true, where: { status: '1', property_type: req.params.id } });
        for (const propertys of property) {
            propertys.children = await PropertyType.findOne({ where: { id: propertys.property_type }, raw: true });
        }

        res.render('property/typeview', {
            page: page,
            property: property,
            cate: cate
        });
    }

    async contact(req, res) {
        try {
            const page = await Page.findOne({ raw: true, where: { status: 1, slug: 'contact' } })
            res.render('contact', {
                page: page
            });
        } catch (error) {
            next(error);
        }

    }

    async ispage(req, res) {
        const ispage = await Page.findOne({ raw: true, where: { status: 1, slug: req.params.slug } })
       
       if(ispage){
        ispage.detail = await processShortcodes(ispage.detail);
       }
        
        res.render('pages', {
            ispage: ispage,
           
        });
    }  
}
module.exports = new SiteController;
