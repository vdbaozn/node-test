const Menu = require("../../models/Menu");
const express = require('express');

class MenuController {
    async index(req, res, next) {
        try {
            const menus = await Menu.findAll({
                where: {
                    parent_id: 0
                },
                order: [['sort', 'ASC']],
                raw: true
            });

            // Lấy tất cả các menu con cho từng menu cha
            for (const menu of menus) {
                menu.children = await Menu.findAll({
                    where: {
                        parent_id: menu.id
                    },
                    raw: true
                });
            }

            res.render('admin/menu/index', {
                layout: '../admin/layout/main',
                menus: menus

            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        try {
            const menus = await Menu.findAll({ where:{status: 1, parent_id: 0}, raw: true });
            const menu_sort = await Menu.findOne({order: [['sort', 'DESC']],raw: true});
            res.render('admin/menu/add', {
                layout: '../admin/layout/main',
                menus: menus,
                menu_sort: menu_sort

            });
        } catch (error) {
            next(error);
        }
    }

    async store(req, res, next) {
        try {
            const formData = req.body;
            const menu = await Menu.create(formData);
            res.redirect('/wp-admin/menu');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const menu = await Menu.findByPk(req.params.id);
            const menus = await Menu.findAll({
                where: {
                    parent_id: 0
                }, raw: true
            });
            if (menu) {
                res.render('admin/menu/edit', {
                    layout: '../admin/layout/main',
                    menus: menus,
                    menu: {
                        id: menu.id,
                        name: menu.dataValues.name,
                        link: menu.dataValues.link,
                        parent_id: menu.dataValues.parent_id,
                        position: menu.dataValues.position,
                        sort: menu.dataValues.sort,
                        status: menu.dataValues.status,
                        createdAt: menu.createdAt,
                        updatedAt: menu.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const menuId = req.params.id;
            const updatedMenu = req.body; // Dữ liệu cập nhật từ request body

            const result = await Menu.update(updatedMenu, {
                where: { id: menuId }
            });

            if (result[0] === 1) {
                res.redirect('/wp-admin/menu');
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Menu.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const menuId = req.params.id;

            const result = await Menu.destroy({
                where: { id: menuId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }


}

module.exports = new MenuController;