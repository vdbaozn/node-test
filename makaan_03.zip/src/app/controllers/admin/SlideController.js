const Slide = require("../../models/Slide");
const express = require('express');
const path = require('path');
const fs = require('fs');

class SlideController {
    async index(req, res, next) {
        try {
            const slide = await Slide.findAll({
                raw: true
            });

            res.render('admin/slide/index', {
                layout: '../admin/layout/main',
                slide: slide
            });
        } catch (error) {
            next(error);
        }
    }


    async add(req, res, next) {
        res.render('admin/slide/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const slide = await Slide.create({ ...formData, imagePath });

            res.redirect('/wp-admin/slide');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const slide = await Slide.findByPk(req.params.id);
            if (slide) {
                res.render('admin/slide/edit', {
                    layout: '../admin/layout/main',
                    slide: {
                        id: slide.id,
                        name: slide.dataValues.name, // Đảm bảo truy cập qua dataValues
                        imagePath: slide.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        createdAt: slide.createdAt,
                        updatedAt: slide.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let slide = await Slide.findByPk(slideId);
            if (!slide) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                slide.name = updatedSlide.name;
            }
            if (imagePath) {
                slide.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await slide.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/slide');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Slide.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await Slide.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new SlideController;