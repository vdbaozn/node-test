const Page = require("../../models/Page");
const express = require('express');
const path = require('path');

class PageController {
    async index(req, res, next) {
        try {
            const page = await Page.findAll({
                raw: true
            });

            res.render('admin/page/index', {
                layout: '../admin/layout/main',
                page: page
            });
        } catch (error) {
            next(error);
        }
    }


    async add(req, res, next) {
        res.render('admin/page/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const page = await Page.create({ ...formData, imagePath });

            res.redirect('/wp-admin/pages');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const page = await Page.findByPk(req.params.id);
            if (page) {
                res.render('admin/page/edit', {
                    layout: '../admin/layout/main',
                    page: {
                        id: page.id,
                        name: page.dataValues.name, // Đảm bảo truy cập qua dataValues
                        slug: page.dataValues.slug,
                        detail: page.dataValues.detail,
                        imagePath: page.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        status: page.dataValues.status,
                        createdAt: page.createdAt,
                        updatedAt: page.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const pageId = req.params.id;
            const updatedPage = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm page cần cập nhật
            let page = await Page.findByPk(pageId);
            if (!page) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của Pages
            if (updatedPage.name) {
                page.name = updatedPage.name;
            }            

            page.detail = updatedPage.detail;

            if (updatedPage.slug) {
                page.slug = updatedPage.slug;
            }

            if (updatedPage.status) {
                page.status = updatedPage.status;
            }else{
                page.status = 0;
            }

            if (imagePath) {
                slide.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await page.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/pages');
            } else {
                res.status(404).send('Pages update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Page.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const pageId = req.params.id;

            const result = await Page.destroy({
                where: { id: pageId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new PageController;