const User = require("../../models/User");
const express = require('express');
const path = require('path');

class UserController {
    async index(req, res, next) {
        try {
            const user = await User.findAll({
                raw: true
            });

            res.render('admin/user/index', {
                layout: '../admin/layout/main',
                user: user
            });
        } catch (error) {
            next(error);
        }
    }


    async add(req, res, next) {
        res.render('admin/user/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const user = await user.create({ ...formData, imagePath });

            res.redirect('/wp-admin/user');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        
        try {
            const users = await User.findByPk(req.params.id);
         
            if (users) {
                res.render('admin/user/edit', {
                    layout: '../admin/layout/main',
                    users: users
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let user = await user.findByPk(slideId);
            if (!user) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                user.name = updatedSlide.name;
            }
            if (updatedSlide.description) {
                user.description = updatedSlide.description;
            }
            if (updatedSlide.designation) {
                user.designation = updatedSlide.designation;
            }
            if (imagePath) {
                user.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await user.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/user');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }


    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await user.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new UserController;