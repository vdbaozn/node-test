// const Property = require("../../models/Property");
const express = require('express');
const path = require('path');
const fs = require('fs');
const Property = require("../../models/Property");
const PropertyType = require("../../models/PropertyType");

class PropertyController {
    async index(req, res, next) {
        try {
            const property = await Property.findAll({
                raw: true
            });

            res.render('admin/property/index', {
                layout: '../admin/layout/main',
                property: property
            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        try {
            const propertyType = await PropertyType.findAll({ raw: true });
            res.render('admin/property/add', {
                layout: '../admin/layout/main',
                propertyType: propertyType

            });
        } catch (error) {
            next(error);
        }
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const property = await Property.create({ ...formData, imagePath });

            res.redirect('/wp-admin/property');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const property = await Property.findByPk(req.params.id);
            const propertyType = await PropertyType.findAll({ raw: true });
            if (property) {
                res.render('admin/property/edit', {
                    layout: '../admin/layout/main',
                    propertyType: propertyType,
                    property: {
                        id: property.id,
                        name: property.dataValues.name, // Đảm bảo truy cập qua dataValues
                        price: property.dataValues.price,
                        address: property.dataValues.address,
                        acreage: property.dataValues.acreage,
                        bed: property.dataValues.bed,
                        bath: property.dataValues.bath,
                        detail: property.detail,
                        property_type: property.dataValues.property_type,
                        imagePath: property.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        createdAt: property.createdAt,
                        updatedAt: property.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let property = await Property.findByPk(slideId);
            if (!property) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                property.name = updatedSlide.name;
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.price) {
                property.price = updatedSlide.price;
            }

            if (updatedSlide.address) {
                property.address = updatedSlide.address;
            }

            if (updatedSlide.acreage) {
                property.acreage = updatedSlide.acreage;
            }

            if (updatedSlide.bed) {
                property.bed = updatedSlide.bed;
            }

            if (updatedSlide.address) {
                property.address = updatedSlide.address;
            }

            if (updatedSlide.property_type) {
                property.property_type = updatedSlide.property_type;
            }

            if (updatedSlide.detail) {
                property.detail = updatedSlide.detail;
            }

            if (updatedSlide.bath) {
                property.bath = updatedSlide.bath;
            }

            if (imagePath) {
                property.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await property.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/property');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Property.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await Property.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new PropertyController;