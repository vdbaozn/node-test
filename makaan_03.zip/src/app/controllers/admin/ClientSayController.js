const ClientSay = require("../../models/ClientSay");
const express = require('express');
const path = require('path');
const fs = require('fs');

class ClientSayController {
    async index(req, res, next) {
        try {
            const clientsay = await ClientSay.findAll({
                raw: true
            });

            res.render('admin/clientsay/index', {
                layout: '../admin/layout/main',
                clientsay: clientsay
            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        res.render('admin/clientsay/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const clientsay = await ClientSay.create({ ...formData, imagePath });

            res.redirect('/wp-admin/clientsay');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const clientsay = await ClientSay.findByPk(req.params.id);
            if (clientsay) {
                res.render('admin/clientsay/edit', {
                    layout: '../admin/layout/main',
                    clientsay: {
                        id: clientsay.id,
                        name: clientsay.dataValues.name,
                        description: clientsay.dataValues.description,
                        designation: clientsay.dataValues.designation, // Đảm bảo truy cập qua dataValues
                        imagePath: clientsay.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        createdAt: clientsay.createdAt,
                        updatedAt: clientsay.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let clientsay = await ClientSay.findByPk(slideId);
            if (!clientsay) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                clientsay.name = updatedSlide.name;
            }
            if (updatedSlide.description) {
                clientsay.description = updatedSlide.description;
            }
            if (updatedSlide.designation) {
                clientsay.designation = updatedSlide.designation;
            }
            if (imagePath) {
                clientsay.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await clientsay.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/clientsay');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await ClientSay.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await ClientSay.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new ClientSayController;