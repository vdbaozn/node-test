const Agent = require("../../models/Agent");
const express = require('express');
const path = require('path');
const fs = require('fs');

class AgentController {
    async index(req, res, next) {
        try {
            const agent = await Agent.findAll({
                raw: true
            });

            res.render('admin/agent/index', {
                layout: '../admin/layout/main',
                agent: agent
            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        res.render('admin/agent/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const agent = await Agent.create({ ...formData, imagePath });

            res.redirect('/wp-admin/agent');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const agent = await Agent.findByPk(req.params.id);
            if (agent) {
                res.render('admin/agent/edit', {
                    layout: '../admin/layout/main',
                    agent: {
                        id: agent.id,
                        name: agent.dataValues.name,
                        designation: agent.dataValues.designation, // Đảm bảo truy cập qua dataValues
                        imagePath: agent.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        createdAt: agent.createdAt,
                        updatedAt: agent.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let agent = await Agent.findByPk(slideId);
            if (!agent) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                agent.name = updatedSlide.name;
            }
            if (updatedSlide.designation) {
                agent.designation = updatedSlide.designation;
            }
            if (imagePath) {
                agent.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await agent.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/agent');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Agent.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await Agent.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new AgentController;