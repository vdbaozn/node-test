const Adminnav = require("../../models/Adminnav");
const express = require('express');

class AdminnavController {
    async index(req, res, next) {
        try {
            const menus = await Adminnav.findAll({
                where: {
                    parent_id: 0
                },
                raw: true
            });

            // Lấy tất cả các menu con cho từng menu cha
            for (const menu of menus) {
                menu.children = await Adminnav.findAll({
                    where: {
                        parent_id: menu.id
                    },
                    raw: true
                });
            }

            res.render('admin/adminnav/index', {
                layout: '../admin/layout/main',
                menus: menus

            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        try {
            const menus = await Adminnav.findAll({ raw: true });
            res.render('admin/adminnav/add', {
                layout: '../admin/layout/main',
                menus: menus

            });
        } catch (error) {
            next(error);
        }
    }

    async store(req, res, next) {
        try {
            const formData = req.body;
            const menu = await Adminnav.create(formData);
            res.redirect('/wp-admin/admin-nav');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const menu = await Adminnav.findByPk(req.params.id);
            const menus = await Adminnav.findAll({
                where: {
                    parent_id: 0
                }, raw: true
            });
            if (menu) {
                res.render('admin/adminnav/edit', {
                    layout: '../admin/layout/main',
                    menus: menus,
                    menu: {
                        id: menu.id,
                        name: menu.dataValues.name,
                        link: menu.dataValues.link,
                        parent_id: menu.dataValues.parent_id,
                        status: menu.dataValues.status,
                        createdAt: menu.createdAt,
                        updatedAt: menu.updatedAt
                    } 
                });
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const menuId = req.params.id;
            const updatedMenu = req.body; // Dữ liệu cập nhật từ request body

            const result = await Adminnav.update(updatedMenu, {
                where: { id: menuId }
            });

            if (result[0] === 1) {
                res.redirect('/wp-admin/admin-nav');
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await Adminnav.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const menuId = req.params.id;

            const result = await Adminnav.destroy({
                where: { id: menuId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Menu not found');
            }
        } catch (error) {
            next(error);
        }
    }


}

module.exports = new AdminnavController;