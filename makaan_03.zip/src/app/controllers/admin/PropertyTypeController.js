const PropertyType = require("../../models/PropertyType");
const express = require('express');
const path = require('path');
const fs = require('fs');

class PropertyTypeController {
    async index(req, res, next) {
        try {
            const propertytype = await PropertyType.findAll({
                raw: true
            });

            res.render('admin/property-type/index', {
                layout: '../admin/layout/main',
                propertytype: propertytype
            });
        } catch (error) {
            next(error);
        }
    }

    async add(req, res, next) {
        res.render('admin/property-type/add', {
            layout: '../admin/layout/main',
        });
    }

    async store(req, res, next) {
        try {
            const formData = req.body;

            if (!req.file) {
                throw new Error('No file uploaded');
            }

            const imagePath = req.file.filename;
            const propertyType = await PropertyType.create({ ...formData, imagePath });

            res.redirect('/wp-admin/property-type');
        } catch (error) {
            next(error);
        }
    }

    async edit(req, res, next) {
        try {
            const propertyType = await PropertyType.findByPk(req.params.id);
            if (propertyType) {
                res.render('admin/property-type/edit', {
                    layout: '../admin/layout/main',
                    propertyType: {
                        id: propertyType.id,
                        name: propertyType.dataValues.name, // Đảm bảo truy cập qua dataValues
                        imagePath: propertyType.dataValues.imagePath, // Đảm bảo truy cập qua dataValues
                        createdAt: propertyType.createdAt,
                        updatedAt: propertyType.updatedAt
                    } // Không cần chuyển đổi như với Mongoose
                });
            } else {
                res.status(404).send('Slide not found 1');
            }
        } catch (error) {
            next(error);
        }
    }

    async update(req, res, next) {
        try {
            const slideId = req.params.id;
            const updatedSlide = req.body; // Dữ liệu cập nhật từ request body
            const imagePath = req.file ? req.file.filename : null; // Tên file hình ảnh từ multer (nếu có)

            // Tìm slide cần cập nhật
            let propertyType = await PropertyType.findByPk(slideId);
            if (!propertyType) {
                throw new Error('Slide not found');
            }

            // Cập nhật dữ liệu của slide
            if (updatedSlide.name) {
                propertyType.name = updatedSlide.name;
            }
            if (imagePath) {
                propertyType.imagePath = imagePath;
            }

            // Lưu các thay đổi vào cơ sở dữ liệu
            const result = await propertyType.save();

            console.log('Update result:', result);

            if (result) {
                res.redirect('/wp-admin/property-type');
            } else {
                res.status(404).send('Slide update failed');
            }
        } catch (error) {
            console.error('Update error:', error);
            next(error);
        }
    }

    async status(req, res) {
        const { id, status } = req.body;
        try {
            await PropertyType.update({ status: status }, { where: { id: id } });
            res.status(200).send('Status updated successfully');
        } catch (error) {
            console.error(error);
            res.status(500).send('Error updating status');
        }
    }

    async destroy(req, res, next) {
        try {
            const slideId = req.params.id;

            const result = await PropertyType.destroy({
                where: { id: slideId }
            });

            if (result === 1) {
                res.redirect('back');
            } else {
                res.status(404).send('Slide not found');
            }
        } catch (error) {
            next(error);
        }
    }
}

module.exports = new PropertyTypeController;