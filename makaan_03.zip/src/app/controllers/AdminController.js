const User = require('../models/User');
const bcrypt = require('bcrypt');

class AdminController {
    index(req, res, next) {
        res.render('admin/index', { layout: '../admin/layout/main' });
    }

    login(req, res, next) {
        res.render('admin/member/login', { layout: '../admin/member/login' });
    }

    async logined(req, res, next) {
        const { username, password } = req.body;
        try {
            console.log('Finding user by username:', username);
            const user = await User.findOne({ where: { username } });

            if (!user) {
                console.log('User not found');
                res.send('Invalid username or password');
                return;
            }

            console.log('User found:', user);
            const passwordMatch = await bcrypt.compare(password, user.password);

            if (passwordMatch) {
                req.session.user = user;
                res.redirect('/wp-admin/dashboard');
            } else {
                console.log('Password does not match');
                res.send('Invalid username or password');
            }
        } catch (err) {
            console.error('Error occurred during login:', err);
            res.send('Error occurred during login');
        }
    }

    async logout(req, res, next) {
        try {
            // Hủy session của người dùng
            req.session.destroy((err) => {
                if (err) {
                    return next(err);
                }
                res.redirect('/wp-admin/login'); // Chuyển hướng đến trang đăng nhập sau khi logout
            });
        } catch (error) {
            next(error);
        }
    }

   
}
module.exports = new AdminController;
