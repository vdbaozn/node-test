const siteRouter = require('./site');
const adminRouter = require('./admin');
const authenticateToken = require('../middleware/auth');
const menuAdmin = require('../middleware/menuAdmin');


function route(app) {
    app.use('/wp-admin',  menuAdmin, adminRouter);
    app.use('/', siteRouter);
}

module.exports = route;