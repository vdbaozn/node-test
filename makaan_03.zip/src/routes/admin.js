const express = require('express');
const router = express.Router();
const adminController = require('../app/controllers/AdminController');
const menuController = require('../app/controllers/admin/MenuController');
const slideController = require('../app/controllers/admin/SlideController');
const propertyTypeController = require('../app/controllers/admin/PropertyTypeController');
const propertyController = require('../app/controllers/admin/PropertyController');
const agentController = require('../app/controllers/admin/AgentController');
const clientSayController = require('../app/controllers/admin/ClientSayController');
const adminNavController = require('../app/controllers/admin/AdminnavController');
const pageController = require('../app/controllers/admin/PageController');
const upload = require('../config/multer');
const { route } = require('./site');

router.get('/pages', pageController.index);
router.get('/pages/add', pageController.add);
router.post('/pages/store', upload.single('image'), pageController.store);
router.get('/pages/:id/edit', pageController.edit);
router.post('/pages/:id/update', upload.single('image'), pageController.update);
router.post('/pages/:id/del', pageController.destroy);
router.post('/pages/status', pageController.status);

router.get('/admin-nav', adminNavController.index);
router.get('/admin-nav/add', adminNavController.add);
router.post('/admin-nav/store', upload.single('image'), adminNavController.store);
router.get('/admin-nav/:id/edit', adminNavController.edit);
router.post('/admin-nav/:id/update', upload.single('image'), adminNavController.update);
router.post('/admin-nav/:id/del', adminNavController.destroy);
router.post('/admin-nav/status', adminNavController.status);

router.get('/clientsay', clientSayController.index);
router.get('/clientsay/add', clientSayController.add);
router.post('/clientsay/store', upload.single('image'), clientSayController.store);
router.get('/clientsay/:id/edit', clientSayController.edit);
router.post('/clientsay/:id/update', upload.single('image'), clientSayController.update);
router.post('/clientsay/:id/del', clientSayController.destroy);
router.post('/clientsay/status', clientSayController.status);

router.get('/agent', agentController.index);
router.get('/agent/add', agentController.add);
router.post('/agent/store', upload.single('image'), agentController.store);
router.get('/agent/:id/edit', agentController.edit);
router.post('/agent/:id/update', upload.single('image'), agentController.update);
router.post('/agent/:id/del', agentController.destroy);
router.post('/agent/status', agentController.status);

router.get('/property', propertyController.index);
router.get('/property/add', propertyController.add);
router.post('/property/store', upload.single('image'), propertyController.store);
router.get('/property/:id/edit', propertyController.edit);
router.post('/property/:id/update', upload.single('image'), propertyController.update);
router.post('/property/:id/del', propertyController.destroy);
router.post('/property/status', propertyController.status);

router.get('/property-type', propertyTypeController.index);
router.get('/property-type/add', propertyTypeController.add);
router.post('/property-type/store', upload.single('image'), propertyTypeController.store);
router.get('/property-type/:id/edit', propertyTypeController.edit);
router.post('/property-type/:id/update', upload.single('image'), propertyTypeController.update);
router.post('/property-type/:id/del', propertyTypeController.destroy);
router.post('/property-type/status', propertyTypeController.status);

router.get('/slide', slideController.index);
router.get('/slide/add', slideController.add);
router.post('/slide/store', upload.single('image'), slideController.store);
router.get('/slide/:id/edit', slideController.edit);
router.post('/slide/:id/update', upload.single('image'), slideController.update);
router.post('/slide/:id/del', slideController.destroy);
router.post('/slide/status', slideController.status);

router.get('/menu', menuController.index);
router.get('/menu/add', menuController.add);
router.post('/menu/store', menuController.store);
router.get('/menu/:id/edit', menuController.edit);
router.post('/menu/:id/update', menuController.update);
router.post('/menu/:id/del', menuController.destroy);
router.post('/menu/status', menuController.status);

router.get('/login', adminController.login);
router.post('/login', adminController.logined);
router.get('/logout', adminController.logout);
router.use('/', adminController.index);

module.exports = router;
