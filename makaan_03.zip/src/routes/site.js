const express = require('express');
const router = express.Router();
const siteController = require('../app/controllers/SiteController');

router.get('/property/:id/view', siteController.propertyview);
router.use('/property-type/:id/view', siteController.propertytypeview);
router.use('/contact', siteController.contact);
router.get('/:slug', siteController.ispage);
router.use('/', siteController.index);

module.exports = router;
